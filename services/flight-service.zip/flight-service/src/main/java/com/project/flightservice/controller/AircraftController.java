package com.project.flightservice.controller;

import com.project.common.response.ApiResponse;
import com.project.flightservice.dto.request.AircraftRequest;
import com.project.flightservice.dto.request.UpdateAircraftStatusRequest;
import com.project.flightservice.dto.response.AircraftResponse;
import com.project.flightservice.service.AircraftService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/aircraft")
@RequiredArgsConstructor
public class AircraftController {

    private final AircraftService aircraftService;

    @PostMapping
    public ResponseEntity<ApiResponse<AircraftResponse>> createAircraft(@Valid @RequestBody AircraftRequest request) {
        AircraftResponse response = aircraftService.createAircraft(request);
        return new ResponseEntity<>(ApiResponse.success("Aircraft created successfully", response), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<AircraftResponse>>> getAllAircraft() {
        List<AircraftResponse> response = aircraftService.getAllAircraft();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<AircraftResponse>> getAircraftById(@PathVariable UUID id) {
        AircraftResponse response = aircraftService.getAircraftById(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<AircraftResponse>> updateAircraft(@PathVariable UUID id, @Valid @RequestBody AircraftRequest request) {
        AircraftResponse response = aircraftService.updateAircraft(id, request);
        return ResponseEntity.ok(ApiResponse.success("Aircraft updated successfully", response));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<AircraftResponse>> updateStatus(@PathVariable UUID id, @Valid @RequestBody UpdateAircraftStatusRequest request) {
        AircraftResponse response = aircraftService.updateStatus(id, request);
        return ResponseEntity.ok(ApiResponse.success("Aircraft status updated successfully", response));
    }
}
