package com.project.flightservice.controller;

import com.project.common.response.ApiResponse;
import com.project.flightservice.dto.request.AirportRequest;
import com.project.flightservice.dto.request.UpdateAirportStatusRequest;
import com.project.flightservice.dto.response.AirportResponse;
import com.project.flightservice.service.AirportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/airports")
@RequiredArgsConstructor
public class AirportController {

    private final AirportService airportService;

    @PostMapping
    public ResponseEntity<ApiResponse<AirportResponse>> createAirport(@Valid @RequestBody AirportRequest request) {
        AirportResponse response = airportService.createAirport(request);
        return new ResponseEntity<>(ApiResponse.success("Airport created successfully", response), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<ApiResponse<List<AirportResponse>>> getAllAirports() {
        List<AirportResponse> response = airportService.getAllAirports();
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<AirportResponse>> getAirportById(@PathVariable UUID id) {
        AirportResponse response = airportService.getAirportById(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/iata/{code}")
    public ResponseEntity<ApiResponse<AirportResponse>> getAirportByIata(@PathVariable String code) {
        AirportResponse response = airportService.getAirportByIata(code);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<AirportResponse>> updateAirport(@PathVariable UUID id, @Valid @RequestBody AirportRequest request) {
        AirportResponse response = airportService.updateAirport(id, request);
        return ResponseEntity.ok(ApiResponse.success("Airport updated successfully", response));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<AirportResponse>> updateStatus(@PathVariable UUID id, @Valid @RequestBody UpdateAirportStatusRequest request) {
        AirportResponse response = airportService.updateStatus(id, request);
        return ResponseEntity.ok(ApiResponse.success("Airport status updated successfully", response));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deleteAirport(@PathVariable UUID id) {
        airportService.deleteAirport(id);
        return ResponseEntity.ok(ApiResponse.success("Airport deactivated successfully", null));
    }
}
