package com.project.flightservice.controller;

import com.project.common.response.ApiResponse;
import com.project.flightservice.dto.request.FlightRequest;
import com.project.flightservice.dto.request.UpdateFlightStatusRequest;
import com.project.flightservice.dto.response.AvailabilityResponse;
import com.project.flightservice.dto.response.FlightResponse;
import com.project.flightservice.dto.response.FlightSearchResponse;
import com.project.flightservice.service.FlightService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/flights")
@RequiredArgsConstructor
public class FlightController {

    private final FlightService flightService;

    @PostMapping
    public ResponseEntity<ApiResponse<FlightResponse>> createFlight(@Valid @RequestBody FlightRequest request) {
        FlightResponse response = flightService.createFlight(request);
        return new ResponseEntity<>(ApiResponse.success("Flight created successfully", response), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<FlightResponse>> getFlightById(@PathVariable UUID id) {
        FlightResponse response = flightService.getFlightById(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<FlightSearchResponse>>> searchFlights(
            @RequestParam String origin,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<FlightSearchResponse> response = flightService.searchFlights(origin, destination, date);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @GetMapping("/{id}/availability")
    public ResponseEntity<ApiResponse<AvailabilityResponse>> getAvailability(@PathVariable UUID id) {
        AvailabilityResponse response = flightService.getAvailability(id);
        return ResponseEntity.ok(ApiResponse.success(response));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<FlightResponse>> updateStatus(
            @PathVariable UUID id, @Valid @RequestBody UpdateFlightStatusRequest request) {
        FlightResponse response = flightService.updateFlightStatus(id, request);
        return ResponseEntity.ok(ApiResponse.success("Flight status updated successfully", response));
    }
}
